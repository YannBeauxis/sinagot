class ConfigurationError(Exception):
    """Exception class for errors in configuration"""
